#include <io_scheduler.h>
#include <kmalloc.h>

static struct bio* disk_head_look;
static struct bio* list_head_look;
static struct bio* list_tail_look;
static int direction_look;
static int request_count; // Maintain request count separately

// Insert a bio request into the scheduling queue, sorted by block number
static void submit_bio(struct bio* request) {
    if(request == NULL){
        return;
    }

    struct bio *p = list_head_look->next;

    while(p->block_num != -1 && request->block_num >= p->block_num) {
        p = p->next;
    }

    request->next = p;
    request->prev = p->prev;
    if(p->prev != NULL){
        p->prev->next = request;
    }
    p->prev = request;
    request_count++;
}

// Initialize the queue, disk_head_look represents the head position, list_head_look and list_tail_look represent the head and tail of the linked list
static int init_queue_look() {
    direction_look = INITIAL_DIRECTION;
    disk_head_look = (struct bio*)kmalloc(sizeof(struct bio));
    if(disk_head_look == NULL){
        kprintf("Memory allocation failed for disk_head_look\n");
        return -1;
    }
    disk_head_look->block_num = INITIAL_HEAD_POS;
    request_count = 0;

    list_head_look = (struct bio*)kmalloc(sizeof(struct bio));
    if(list_head_look == NULL){
        kprintf("Memory allocation failed for list_head_look\n");
        kfree(disk_head_look);
        return -1;
    }
    list_head_look->block_num = -1;

    list_tail_look = (struct bio*)kmalloc(sizeof(struct bio));
    if(list_tail_look == NULL){
        kprintf("Memory allocation failed for list_tail_look\n");
        kfree(disk_head_look);
        kfree(list_head_look);
        return -1;
    }
    list_tail_look->block_num = -1;

    disk_head_look->next = list_tail_look;
    disk_head_look->prev = list_head_look;
    list_head_look->next = disk_head_look;
    list_head_look->prev = NULL;
    list_tail_look->next = NULL;
    list_tail_look->prev = disk_head_look;

    return 0;
}

int* look_schedule(int *begin_pos, int *begin_direction, int *size) {
    struct bio* current;
    int* traversed_blocks = (int*)kmalloc(request_count * sizeof(int));
    int count = 0;

    *begin_pos = disk_head_look->block_num;
    *begin_direction = direction_look;
    kprintf("begin_pos = %d, begin_direction = %d\n", *begin_pos, *begin_direction);
#ifdef LAB10_EX1
    // LAB10 EXERCISE1: YOUR CODE
        int flag = disk_head_look->block_num;
        while (1) {
        if (*begin_direction == 1 && request_count){
            current = disk_head_look->next;
            while(current != list_tail_look && current->block_num != -1){
                if (current->block_num == flag){
                    current = current->next;
                    continue;
                }
                traversed_blocks[count] = current->block_num;
                count++;
                kprintf("Serving block: %d\n", current->block_num);
                *begin_pos = current->block_num;
                disk_head_look->next = current->next;
                if(current->next != NULL){
                    current->next->prev = disk_head_look;
                }
                kfree(current);
                request_count--;
                current = disk_head_look->next;
            }
            *begin_direction = -1;
        }
        if (*begin_direction == -1 && request_count){
            current = disk_head_look->prev;
            while(current != list_head_look && current->block_num != -1){
                if (current->block_num == flag){
                    current = current->prev;
                    continue;
                }
                traversed_blocks[count] = current->block_num;
                count++;
                kprintf("Serving block: %d\n", current->block_num);
                *begin_pos = current->block_num;
                disk_head_look->prev = current->prev;
                if(current->prev != NULL){
                    current->prev->next = disk_head_look;
                }
                kfree(current);
                request_count--;
                current = disk_head_look->prev;
            }
            *begin_direction = 1;
        }
        break;
    }
    *begin_pos = flag;
    *size = count;
#endif
    request_count = 0;
    return traversed_blocks;
}

struct io_scheduler default_scheduler = {
    .init_queue = init_queue_look,
    .submit_bio = submit_bio,
    .schedule = look_schedule,
};
